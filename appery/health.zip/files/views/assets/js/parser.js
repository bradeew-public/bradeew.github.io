var br = '<br />';
//get Demographic info using jquery DOM
function getDemographicInfo(document) {
    var patient = $(document).find("patient");
    var first = patient.find('given').text();
    var last = patient.find('family').text();
    var gender = patient.find('administrativeGenderCode').attr('code');
    var birthTime = patient.find('birthTime').attr('value');
    var race = patient.find('raceCode').attr('displayName');
    var ethnic = patient.find('ethnicGroupCode').attr('displayName');
    
    $("#anotherElement").append("First: " + first + br);
    $("#anotherElement").append("Last: " + last + br);
    $("#anotherElement").append("Gender: " + gender + br);
    $("#anotherElement").append("Birth Date: " + birthTime + br);
    $("#anotherElement").append("Race: " + race + br);
    $("#anotherElement").append("Ethnic: " + ethnic + br);
    
}
//get Demographic info using jquery DOM
function getPatientInfo (document) {
    var pr = $(document).find("patientRole");
    var addr = pr.find('addr');
    var patient = $(document).find("patient");
    // format birtdate
    var bt = patient.find('birthTime').attr('value'); // YYYYMMDD
    var bd = bt.substring(4,6) + "/" + bt.substring(6,8) + "/" + bt.substring(0,4);
    var tel = pr.find('telecom').attr('value');
    tel = tel.substring(4, tel.length);
    return {
        firstName  : patient.find('given').text(),
        lastName   : patient.find('family').text(),
        suffix     : patient.find('suffix').text(),
        gender     : patient.find('administrativeGenderCode').attr('code'),
        birthDate  : bd,
        race       : patient.find('raceCode').attr('displayName'),
        ethnicity  : patient.find('ethnicGroupCode').attr('displayName'),
        ssn        : pr.find('id').attr('extension'),
        street     : addr.find('streetAddressLine').text(),
        city       : addr.find('city').text(),
        state      : addr.find('state').text(),
        country    : addr.find('country').text(),
        postalCode : addr.find('postalCode').text(),
        phoneNumber : function () {
            var tel = pr.find('telecom').attr('value');
            return tel.substring(4, tel.length);
        }
    };
}

function getAuthor(document){
    var author = $(document).find("author");
    var addr = author.find("assignedAuthor").find('addr');
    var ap = $(document).find("assignedPerson");

    return {
        firstName  : ap.find('given').text(),
        lastName   : ap.find('family').text(),
        prefix     : ap.find('prefix').text(),
        TIN        : author.find("assignedAuthor").find('id').attr('extension'),
        street     : addr.find('streetAddressLine').text(),
        city       : addr.find('city').text(),
        state      : addr.find('state').text(),
        country    : addr.find('country').text(),
        postalCode : addr.find('postalCode').text(),
        phoneNumber : function () {
            var tel = author.find("assignedAuthor").find('telecom').attr('value');
            return tel.substring(4, tel.length);
        }

    };
}

// get address information
//get Demographic info using jquery DOM
function getAddress(document, role) {
    var role = $(document).find("patient");
    var bt = patient.find('birthTime').attr('value'); // YYYYMMDD
    var bd = bt.substring(4,6) + "/" + bt.substring(6,8) + "/" + bt.substring(0,4);
    return {
        firstName : patient.find('given').text(),
        lastName  : patient.find('family').text(),
        gender    : patient.find('administrativeGenderCode').attr('code'),
        birthDate : bd,
        race      : patient.find('raceCode').attr('displayName'),
        ethnicity : patient.find('ethnicGroupCode').attr('displayName')
    };
}

//use json to get array of json objects
function getData(data, index) {
    var components = data.component.structuredBody.component;
    var com = components[index].section.text[0].table;
    labels = getTableHeader(com.thead);
    values = getValues(com.tbody, labels);
    
    return values;
}


// this is just a placeholder to print all values
function appendValues(values, name) {
    $("#anotherElement").append(br + 'Section ' + name + br);
    
    for (var x in values) {
        $("#anotherElement").append(br + name + ' ' + x + br);
        for (var y in values[x]) {
            $("#anotherElement").append(y + ": " + values[x][y] + br);
        }
    }
    
}

function getTableHeader(head) {
    var labels = [];
    var values = head.tr.th;
    
    for (var v in values) {
        labels[labels.length] = values[v];
    }
    return labels;
}

function getValues(body, labels) {
    var values = [];
    var encounters = body.tr;
    for (var v in encounters) {
        var encounter = encounters[v].td;
        var newEncounter = {};
        for (var u in encounter) {
            if (typeof encounter[u] != "string") {
                if ('text' in encounter[u]) {
                    newEncounter[labels[u]] = encounter[u];
                } else {
                    newEncounter[labels[u]] = encounter[u].content;
                }
            } else {
                newEncounter[labels[u]] = encounter[u];
            }
        }
        values[values.length] = newEncounter;
    }
    return values;
}