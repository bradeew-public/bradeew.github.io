/*
 * Services
 */

var loadXML = new Apperyio.RestService({
    'url': 'ccd.xml',
    'dataType': 'xml',
    'type': 'get',
});
getDemographicInfo = new Apperyio.parseContactInfo({});