var ccdXmlDoc = ""; // store the XML version of the CCD here
var allergies;
var encounters;
var vaccinations;
var medications;
var testResults;
var vitals;

function loadCCD(){
 	$.ajax({
		type: "GET",
		url: "ccd.xml",
		dataType: "xml",
		success: parseXML
	});
}

function parseXML(xml){
    ccdXmlDoc = xml;
    demos.execute({});
	var j = $.xml2json(xml);
    allergies = getData(j, 0);
	encounters = getData(j, 1);
	vaccinations = getData(j, 2);
	medications = getData(j, 3);
    
    //use test results data to make chart
	makeChart(testResults);
}

function displayPatientInfo(data){
    Appery("name").text(data.lastName + ", " + data.firstName);
    Appery("addr1").text(data.street);
    Appery("addr2").text(data.city + "," + data.state + " " + data.postalCode);
    Appery("tel").text(data.phoneNumber);
}

